# TheSuq storefront preview (Phase 1)

A static, no-backend preview of the TheSuq buyer experience. All products, sellers and orders are fictional demo data.

## Run it
Open `index.html` in a browser, or serve the folder: `python3 -m http.server 8080` then visit http://localhost:8080.

## What works
- Home, categories, search, filters (category, seller state, price in ₦, in stock, verified), sorting, pagination
- Product pages with variants, per-variant stock limits, wishlist, report listing, WhatsApp seller button
- Seller storefronts; cart grouped by seller with state-based delivery fees, save for later, coupon `DEMO10`
- Checkout with Nigerian phone and address validation; creates a **demo order** with status "Pending payment"
- Policy and help pages (drafts), Build status page, demo Settings page

## What is NOT built (see docs/phased-prompts.md)
Accounts, database, seller onboarding and dashboard, Paystack/Flutterwave, webhooks, refunds, admin dashboard, moderation, real reviews. Nothing here charges money or contacts sellers.

## WhatsApp
Demo sellers have no phone numbers on purpose. Open Settings and enter a number you own to test the `wa.me` links, and the official TheSuq support number when you have one. Links use `https://wa.me/<digits>?text=<URL-encoded message>`.

## Files
- `index.html`, `styles.css`, `app.js` – the app
- `assets/` – logos (light and dark SVG), favicon, original logo crop
- `docs/brand-kit.md` – palette and logo notes
- `docs/phased-prompts.md` – the master prompt split into 5 buildable phases

# TheSuq brand kit

Derived from the supplied logo (white wordmark, lime shopping-bag "u", "MARKETPLACE" tagline on deep green).

| Token | Hex | Use |
|---|---|---|
| Emerald 900 (logo background) | #012F24 | Header, footer, dark surfaces |
| Emerald 700 | #0B5D45 | Primary buttons on light backgrounds |
| Lime (logo bag) | #A3E939 | Accent on dark; highlights, badges on emerald |
| Ivory | #FAF7EF | Page background |
| Charcoal | #1F2A27 | Body text |
| Muted gold | #C9A227 | Sparing decorative accents |

Notes
- The lime green fails contrast on ivory/white. Use it only on emerald; use Emerald 700 for buttons/links on light backgrounds.
- The supplied logo's green (#012F24) is darker than a typical "emerald"; the master prompt's "deep emerald" is matched by Emerald 900/700.
- `logo-dark.svg` / `logo-light.svg` are vector recreations of the supplied logo (the original is a JPEG). Check them against the original and replace with a designer-made vector when available.
- Files: logo-dark.svg, logo-light.svg, favicon.svg, favicon-32.png, apple-touch-icon.png, favicon-512.png, plus the original crop (logo-dark-crop.png).

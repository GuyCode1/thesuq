# TheSuq: phased build prompts

Paste **Shared context** at the top of every phase, then the phase prompt. Finish and test each phase before starting the next. Attach the logo files from `assets/` in Phase 1.

## Shared context (paste with every phase)

```
Project: TheSuq, a Shariah-conscious multi-vendor online marketplace for Nigeria.
Brand: exact spelling "TheSuq". Logo files attached (logo-dark.svg, logo-light.svg, favicon.svg).
Colours: Emerald 900 #012F24, Emerald 700 #0B5D45, lime accent #A3E939 (only on dark backgrounds),
ivory #FAF7EF, charcoal #1F2A27, muted gold #C9A227 (sparingly).
Defaults: Nigeria, NGN (₦), all 36 states + FCT, mobile-first, low-data, WCAG AA.
Rules that apply to every phase:
- Never fake a payment, verification, review, delivery status, certification or metric.
  Sample data must be labelled "Demo data".
- Never claim escrow, split payments, payouts or buyer protection unless verified with the provider.
- Never claim products or sellers are Shariah-certified without a documented review.
- Secrets only on the server. Never in client code, logs or the repo.
- Legal and Shariah pages are editable DRAFTS marked "professional review required before launch".
- At the end of the phase, give me a test report: passed / failed / not configured.
```

## Phase 1: Storefront and brand (buyer-facing)

```
Build the buyer-facing storefront: header (announcement bar, search, state selector, account, wishlist,
cart, category nav), homepage, browse/search with filters (category, state, price range in ₦, in stock,
verified seller, sort, pagination, empty states), product detail (images, variants, quantity, stock,
seller info, returns info, report listing, add to cart, "Chat with Seller on WhatsApp"), seller
storefront page, cart (grouped by seller, delivery fee, total), and the policy/help pages as drafts.
WhatsApp: use https://wa.me/<international number without +>?text=<URL-encoded message>. Pre-filled message:
"Assalamu alaikum. I am interested in [Product] on TheSuq. Please confirm availability, final price,
delivery options to [Location], and expected delivery time. Thank you." Support number is configurable.
Show anti-scam guidance and that WhatsApp chats may not be visible to TheSuq support.
Use 12-20 clearly labelled fictional products across: modest fashion, home, electronics, books,
permitted food, beauty, crafts, business supplies, services. No fake ratings or "X sold" claims.
Acceptance: search/filter work, out-of-stock items cannot be added, cart maths correct, NGN formatting
correct, WhatsApp links encode correctly, works at 360px width, keyboard navigable.
```

## Phase 2: Accounts, database and seller tools

```
Add a PostgreSQL backend (Supabase or similar) with migrations, row-level security and these tables:
users, roles, profiles, addresses, sellers, seller_verifications, categories, products, product_images,
variants, inventory, carts, cart_items, orders, seller_suborders, order_items, order_events,
reviews, reports, support_tickets, settings, audit_logs.
Implement register/login/logout/password reset, role-aware navigation, buyer dashboard (profile,
addresses, orders, wishlist), seller onboarding (business details, phone, state, documents uploaded to
private storage, status), seller dashboard (listings CRUD, stock, orders, enquiries), and a restricted-item
check on listings against a configurable prohibited-products list.
Acceptance: a seller cannot read or edit another seller's data (write tests proving it), stock cannot go
negative, uploads limited by type and size, rate limiting on auth.
```

## Phase 3: Checkout and payments (sandbox only)

```
Implement checkout (Nigerian phone validation, state, LGA/city, address, landmark, delivery or pickup,
coupon, terms acceptance) creating an order with seller suborders, then payment via Paystack and/or
Flutterwave in SANDBOX mode through a server endpoint.
Mark an order paid only after server-side verification or a signature-validated webhook, matching
reference, order, amount and currency. Make webhooks idempotent (store event ids). Handle failed, pending,
abandoned, delayed and duplicate events and allow safe retry without duplicate orders.
Store references, amounts, status, timestamps. Never store card data. Refunds only update status when the
provider confirms. Do not assume escrow or automatic seller payouts; record per-seller allocations and
fees and show a clear SANDBOX banner.
Acceptance tests: valid, invalid-signature, duplicate, wrong-amount, delayed and failed webhooks.
Provide .env.example (names only) and webhook/callback setup docs.
```

## Phase 4: Admin, moderation and trust

```
Build the TheSuq Admin Dashboard: users and roles, seller verification (reviewer, scope, date, evidence
recorded), product moderation queue, reports and disputes, categories, orders, payments and refunds,
fees/commissions, delivery zones and fees, return windows, homepage banners, support WhatsApp number,
logo/colour/contact settings, policy pages with version history, audit log (no secrets or passwords).
Customer-facing: report listing/seller, dispute flow, reviews limited to completed purchases with
moderation. All dashboard figures come from real data or are labelled demo.
Acceptance: moderators cannot change payment settings, every sensitive admin action is logged,
branding changes apply without code edits.
```

## Phase 5: Hardening and launch pack

```
Run an accessibility pass (WCAG AA), performance pass (image optimisation, lazy loading), SEO (titles,
meta, canonical, sitemap, robots, structured data, share previews), and a security review (XSS, CSRF,
IDOR, upload safety, secret exposure in bundles and logs).
Produce: setup/deploy/backup/recovery docs, a full test report, a list of unfinished integrations and
required credentials, and a launch checklist covering: Shariah adviser review (products, fees, payment
flow, refund rules, prohibited list), Nigerian legal review (consumer protection, tax, payment services,
NDPA data protection, e-commerce), payment-provider approval, and penetration testing.
Do not state the platform is secure or compliant; state what was tested and what remains.
```

## Decisions only you can make

1. Fees: commission %, listing fees, subscriptions.
2. Whether you will hold funds (escrow/wallet), which needs regulatory advice, or let the payment provider settle sellers directly.
3. Which Shariah adviser and which Nigerian law firm will review the policies.
4. Whether the seller verification badge means identity/business checks only (recommended) or also a product review.
5. Which delivery partners or couriers to support first.

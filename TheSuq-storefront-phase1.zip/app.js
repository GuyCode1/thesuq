/* TheSuq storefront preview (static, no backend). All data is fictional demo data. */
(function () {
'use strict';

/* ---------- constants & data ---------- */
var STATES = ['Abia','Adamawa','Akwa Ibom','Anambra','Bauchi','Bayelsa','Benue','Borno','Cross River','Delta','Ebonyi','Edo','Ekiti','Enugu','FCT (Abuja)','Gombe','Imo','Jigawa','Kaduna','Kano','Katsina','Kebbi','Kogi','Kwara','Lagos','Nasarawa','Niger','Ogun','Ondo','Osun','Oyo','Plateau','Rivers','Sokoto','Taraba','Yobe','Zamfara'];

var CATS = [
  {id:'fashion', name:'Fashion and modest wear', ico:'👗', tint:'#F3E3EA', blurb:'Abayas, jalabiyas, hijabs and everyday wear from independent sellers.'},
  {id:'home', name:'Home and living', ico:'🏠', tint:'#E5EEDD', blurb:'Decor, kitchen and household items.'},
  {id:'electronics', name:'Electronics', ico:'🔌', tint:'#DDE8F3', blurb:'Phones accessories, audio and power.'},
  {id:'books', name:'Books and education', ico:'📚', tint:'#F1E8D3', blurb:'Textbooks, workbooks and learning materials.'},
  {id:'food', name:'Food and groceries', ico:'🌴', tint:'#F4EAD0', blurb:'Permitted food items. Sellers must follow the Prohibited Products Policy.'},
  {id:'beauty', name:'Beauty and personal care', ico:'🧴', tint:'#F6E4DA', blurb:'Natural and everyday personal care.'},
  {id:'crafts', name:'Crafts and handmade', ico:'🧵', tint:'#EADFF0', blurb:'Handmade goods from Nigerian artisans.'},
  {id:'business', name:'Business supplies', ico:'📦', tint:'#E2E8E4', blurb:'Stationery and supplies for shops and offices.'},
  {id:'services', name:'Services', ico:'✂️', tint:'#E3EEF0', blurb:'Permitted services. Arranged directly with the provider.'}
];

// None of these sellers is verified. Numbers are intentionally absent: contact numbers come from Settings.
var SELLERS = [
  {id:'s1', name:'Noor Modest Wear', state:'Kano', city:'Kano', pickup:true, feeSame:1500, feeOther:3800, nationwide:true, desc:'Demo seller. Modest clothing and scarves.'},
  {id:'s2', name:'Ilorin Home Crafts', state:'Kwara', city:'Ilorin', pickup:true, feeSame:1200, feeOther:3500, nationwide:true, desc:'Demo seller. Handmade home goods and leatherwork.'},
  {id:'s3', name:'Lagos Tech Corner', state:'Lagos', city:'Ikeja', pickup:true, feeSame:1500, feeOther:3000, nationwide:true, desc:'Demo seller. Phone accessories and audio.'},
  {id:'s4', name:'Arewa Pantry', state:'Kaduna', city:'Kaduna', pickup:false, feeSame:1500, feeOther:4200, nationwide:true, desc:'Demo seller. Dates, honey and dried goods.'},
  {id:'s5', name:'Ibadan Book Nook', state:'Oyo', city:'Ibadan', pickup:true, feeSame:1000, feeOther:2800, nationwide:true, desc:'Demo seller. Textbooks and children\'s workbooks.'},
  {id:'s6', name:'Abuja Office Hub', state:'FCT (Abuja)', city:'Wuse', pickup:true, feeSame:1500, feeOther:3200, nationwide:false, deliverStates:['FCT (Abuja)','Niger','Nasarawa','Kaduna','Kogi'], desc:'Demo seller. Stationery and shop supplies. Delivers to nearby states only.'},
  {id:'s7', name:'Zainab Glow Naturals', state:'Lagos', city:'Lekki', pickup:false, feeSame:1500, feeOther:3200, nationwide:true, desc:'Demo seller. Shea butter and natural oils.'},
  {id:'s8', name:'Sahara Tailors', state:'Kano', city:'Kano', pickup:true, feeSame:0, feeOther:0, nationwide:false, deliverStates:['Kano'], service:true, desc:'Demo seller. Tailoring service in Kano.'}
];

function V(label, stock){ return {id:label.toLowerCase().replace(/[^a-z0-9]+/g,'-'), label:label, stock:stock}; }
var PRODUCTS = [
  {id:'p1', name:'Jersey Abaya, Black', cat:'fashion', seller:'s1', price:28500, was:32000, emoji:'🧕', cond:'New', vlabel:'Size', variants:[V('52',5),V('54',0),V('56',3)], desc:'Lightweight jersey abaya with a relaxed fit. Measurements are listed in the specifications.', specs:['Fabric: jersey','Length options: 52, 54, 56 inches','Colour: black'], returns:'Returns within 3 days if unworn and unwashed.'},
  {id:'p2', name:'Men\'s Cotton Jalabiya', cat:'fashion', seller:'s1', price:24000, emoji:'👘', cond:'New', vlabel:'Size', variants:[V('M',6),V('L',4),V('XL',2)], desc:'Breathable cotton jalabiya for everyday and Friday wear.', specs:['Fabric: cotton','Colour: off-white'], returns:'Exchange for size within 3 days.'},
  {id:'p3', name:'Chiffon Hijab Scarf, Pack of 3', cat:'fashion', seller:'s1', price:6500, emoji:'🧣', cond:'New', vlabel:'Colour set', variants:[V('Neutral',12),V('Jewel tones',8)], desc:'Soft chiffon scarves, three per pack.', specs:['Pack quantity: 3','Size: 180 x 70 cm'], returns:'Unopened packs can be returned within 3 days.'},
  {id:'p4', name:'Handwoven Prayer Mat', cat:'home', seller:'s2', price:9500, emoji:'🕌', cond:'New', vlabel:'Colour', variants:[V('Green',7),V('Sand',5)], desc:'Handwoven mat with a padded feel.', specs:['Size: 70 x 110 cm','Handmade'], returns:'Returns accepted if damaged on arrival.'},
  {id:'p5', name:'Brass Decorative Tray', cat:'home', seller:'s2', price:18000, emoji:'🥘', cond:'New', vlabel:'Size', variants:[V('Medium',4),V('Large',2)], desc:'Hand-finished brass serving or display tray.', specs:['Material: brass'], returns:'Returns accepted if damaged on arrival.'},
  {id:'p6', name:'Clay Water Pot Set', cat:'home', seller:'s2', price:12500, emoji:'🏺', cond:'New', vlabel:'Set', variants:[V('Set of 2',0),V('Set of 3',0)], desc:'Traditional clay pots. Currently out of stock.', specs:['Material: fired clay'], returns:'Not returnable unless damaged on arrival.'},
  {id:'p7', name:'Wireless Earbuds', cat:'electronics', seller:'s3', price:19500, was:24000, emoji:'🎧', cond:'New', vlabel:'Colour', variants:[V('Black',10),V('White',6)], desc:'Bluetooth earbuds with charging case.', specs:['Bluetooth 5.x','Charging case included','Seller warranty: confirm with seller'], returns:'7-day return for faulty items.'},
  {id:'p8', name:'20,000 mAh Power Bank', cat:'electronics', seller:'s3', price:17500, emoji:'🔋', cond:'New', vlabel:'Colour', variants:[V('Black',9)], desc:'Dual-USB power bank for outages and travel.', specs:['Capacity: 20,000 mAh','Ports: 2 x USB-A, 1 x USB-C'], returns:'7-day return for faulty items.'},
  {id:'p9', name:'USB-C Charging Cable, Pack of 3', cat:'electronics', seller:'s3', price:4500, emoji:'🔌', cond:'New', vlabel:'Length', variants:[V('1 m',30),V('2 m',18)], desc:'Braided USB-C cables.', specs:['Pack quantity: 3'], returns:'7-day return for faulty items.'},
  {id:'p10', name:'Hausa and English Primer', cat:'books', seller:'s5', price:3500, emoji:'📖', cond:'New', vlabel:'Edition', variants:[V('Paperback',20)], desc:'Beginner reading primer.', specs:['Pages: 96','Format: paperback'], returns:'Returns accepted if damaged on arrival.'},
  {id:'p11', name:'Children\'s Arabic Alphabet Workbook', cat:'books', seller:'s5', price:2800, emoji:'✏️', cond:'New', vlabel:'Edition', variants:[V('Paperback',25)], desc:'Tracing and colouring practice for young learners.', specs:['Pages: 48'], returns:'Returns accepted if damaged on arrival.'},
  {id:'p12', name:'Premium Dates, 1 kg', cat:'food', seller:'s4', price:9800, emoji:'🌴', cond:'New', vlabel:'Pack', variants:[V('1 kg',15)], desc:'Soft, sweet dates. Check the best-before date with the seller.', specs:['Net weight: 1 kg','Storage: cool, dry place'], returns:'Food items are not returnable unless spoiled or wrong item.'},
  {id:'p13', name:'Dried Hibiscus (Zobo), 500 g', cat:'food', seller:'s4', price:2500, emoji:'🌺', cond:'New', vlabel:'Pack', variants:[V('500 g',40)], desc:'Dried hibiscus calyces for zobo drink.', specs:['Net weight: 500 g'], returns:'Food items are not returnable unless spoiled or wrong item.'},
  {id:'p14', name:'Pure Honey, 750 ml', cat:'food', seller:'s4', price:8500, emoji:'🍯', cond:'New', vlabel:'Pack', variants:[V('750 ml',11)], desc:'Raw honey from a small apiary.', specs:['Volume: 750 ml'], returns:'Food items are not returnable unless spoiled or wrong item.'},
  {id:'p15', name:'Shea Butter, 500 g', cat:'beauty', seller:'s7', price:4800, emoji:'🧈', cond:'New', vlabel:'Type', variants:[V('Unrefined',14),V('Whipped',9)], desc:'Shea butter for skin and hair.', specs:['Net weight: 500 g'], returns:'Opened items are not returnable.'},
  {id:'p16', name:'Black Seed Oil, 100 ml', cat:'beauty', seller:'s7', price:6200, emoji:'🫙', cond:'New', vlabel:'Size', variants:[V('100 ml',8)], desc:'Cold-pressed black seed oil. Not a medicine; no health claims are made.', specs:['Volume: 100 ml'], returns:'Opened items are not returnable.'},
  {id:'p17', name:'Handmade Leather Sandals', cat:'crafts', seller:'s2', price:11000, emoji:'👡', cond:'New', vlabel:'Size (EU)', variants:[V('40',3),V('41',4),V('42',4),V('43',2),V('44',0)], desc:'Hand-stitched leather sandals.', specs:['Material: leather'], returns:'Size exchange within 3 days if unworn.'},
  {id:'p18', name:'A5 Ledger Notebooks, Pack of 5', cat:'business', seller:'s6', price:5500, emoji:'📒', cond:'New', vlabel:'Ruling', variants:[V('Ruled',25),V('Squared',10)], desc:'Hardback ledgers for small business records.', specs:['Size: A5','Pack quantity: 5'], returns:'Returns accepted if damaged on arrival.'},
  {id:'p19', name:'Thermal Receipt Rolls, Box of 20', cat:'business', seller:'s6', price:7800, emoji:'🧾', cond:'New', vlabel:'Width', variants:[V('57 mm',16),V('80 mm',12)], desc:'Thermal paper rolls for POS printers.', specs:['Rolls per box: 20'], returns:'Unopened boxes returnable within 3 days.'},
  {id:'p20', name:'Custom Kaftan Tailoring', cat:'services', seller:'s8', price:15000, emoji:'✂️', cond:'Service', svc:true, vlabel:'Style', variants:[V('Standard kaftan',99),V('Embroidered kaftan',99)], desc:'Tailoring service. Fabric not included. Measurements and timelines are agreed with the tailor.', specs:['Fabric is supplied by the buyer or arranged separately','Timeline agreed with the seller'], returns:'Alterations offered. Refunds follow the Returns Policy for services.'}
];

var SETTINGS_DEFAULT = {
  supportWa: '',                // TheSuq support WhatsApp (international format). Set in Settings.
  demoSellerWa: '',             // For testing seller links only. Applied to all demo sellers in this preview.
  announce: 'Preview build with fictional demo data. No real payments or orders.'
};

/* ---------- pure helpers (testable) ---------- */
function esc(s){ return String(s == null ? '' : s).replace(/[&<>"']/g, function(c){ return {'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]; }); }
function fmtNGN(n){ return '₦' + Math.round(n).toLocaleString('en-NG'); }

// Returns digits-only international number, or null if not plausible. Accepts +234..., 234..., 0803...
function normalizeWaNumber(raw){
  var d = String(raw || '').replace(/[\s\-().]/g,'');
  if (/^\+/.test(d)) d = d.slice(1);
  if (!/^\d+$/.test(d)) return null;
  if (/^0\d{10}$/.test(d)) d = '234' + d.slice(1);
  if (d.length < 10 || d.length > 15) return null;
  if (d.indexOf('234') === 0 && d.length !== 13) return null;
  return d;
}
function waLink(raw, text){
  var n = normalizeWaNumber(raw);
  if (!n) return null;
  return 'https://wa.me/' + n + '?text=' + encodeURIComponent(text);
}
function enquiryText(productName, location){
  return 'Assalamu alaikum. I am interested in ' + productName + ' on TheSuq. Please confirm availability, final price, delivery options to ' + location + ', and expected delivery time. Thank you.';
}
function isNgPhone(p){ return /^(\+?234|0)[789][01]\d{8}$/.test(String(p||'').replace(/[\s\-]/g,'')); }

function sellerById(id){ return SELLERS.filter(function(s){return s.id===id;})[0]; }
function productById(id){ return PRODUCTS.filter(function(p){return p.id===id;})[0]; }
function catById(id){ return CATS.filter(function(c){return c.id===id;})[0]; }
function variantOf(p, vid){ return p.variants.filter(function(v){return v.id===vid;})[0]; }
function totalStock(p){ return p.variants.reduce(function(a,v){return a+v.stock;},0); }

function canDeliver(seller, state){
  if (seller.nationwide) return true;
  return (seller.deliverStates || []).indexOf(state) !== -1;
}
function deliveryFee(seller, state, product){
  if (product && product.svc) return 0;
  if (!canDeliver(seller, state)) return null;
  return seller.state === state ? seller.feeSame : seller.feeOther;
}

// lines: [{pid,vid,qty}] -> groups by seller with fee, subtotal. mode: 'delivery'|'pickup'
function computeCart(lines, state, mode, coupon){
  var groups = {}, subtotal = 0, problems = [];
  lines.forEach(function(l){
    var p = productById(l.pid); if (!p) return;
    var v = variantOf(p, l.vid); if (!v) return;
    if (l.qty > v.stock) problems.push(p.name + ' (' + v.label + '): only ' + v.stock + ' in stock');
    var s = sellerById(p.seller);
    if (!groups[s.id]) groups[s.id] = {seller:s, lines:[], subtotal:0, fee:0, blocked:false};
    var g = groups[s.id];
    g.lines.push({p:p, v:v, qty:l.qty, line:p.price*l.qty});
    g.subtotal += p.price * l.qty;
    subtotal += p.price * l.qty;
  });
  var feeTotal = 0;
  Object.keys(groups).forEach(function(id){
    var g = groups[id];
    if (mode === 'pickup') {
      g.fee = 0;
      if (!g.seller.pickup && !g.lines.every(function(x){return x.p.svc;})) { g.blocked = true; problems.push(g.seller.name + ' does not offer pickup'); }
    } else {
      var svcOnly = g.lines.every(function(x){return x.p.svc;});
      if (svcOnly) g.fee = 0;
      else if (!canDeliver(g.seller, state)) { g.blocked = true; g.fee = 0; problems.push(g.seller.name + ' does not deliver to ' + state); }
      else g.fee = (g.seller.state === state) ? g.seller.feeSame : g.seller.feeOther;
    }
    feeTotal += g.fee;
  });
  var discount = 0;
  if (coupon && String(coupon).toUpperCase() === 'DEMO10') discount = Math.round(subtotal * 0.10);
  return {groups:groups, subtotal:subtotal, delivery:feeTotal, discount:discount, total:subtotal + feeTotal - discount, problems:problems};
}

var api = {esc:esc, fmtNGN:fmtNGN, normalizeWaNumber:normalizeWaNumber, waLink:waLink, enquiryText:enquiryText, isNgPhone:isNgPhone, computeCart:computeCart, PRODUCTS:PRODUCTS, SELLERS:SELLERS, STATES:STATES, deliveryFee:deliveryFee};
if (typeof module !== 'undefined' && module.exports) module.exports = api;
if (typeof document === 'undefined') return;

/* ---------- storage ---------- */
function load(k, d){ try { var v = localStorage.getItem('thesuq.' + k); return v ? JSON.parse(v) : d; } catch(e){ return d; } }
function save(k, v){ try { localStorage.setItem('thesuq.' + k, JSON.stringify(v)); } catch(e){} }
var settings = Object.assign({}, SETTINGS_DEFAULT, load('settings', {}));
var cart = load('cart', []);
var wish = load('wish', []);
var orders = load('orders', []);
var recent = load('recent', []);
var myState = load('state', 'Lagos');

/* ---------- ui helpers ---------- */
var $ = function(s, r){ return (r||document).querySelector(s); };
var mainEl = $('#main');
function toast(msg){ var t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(toast._t); toast._t=setTimeout(function(){t.classList.remove('show');},2600); }
function img(p){
  var c = catById(p.cat);
  var svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 400 400"><rect width="400" height="400" fill="'+c.tint+'"/><text x="200" y="215" font-size="150" text-anchor="middle" dominant-baseline="middle">'+p.emoji+'</text><text x="200" y="380" font-size="16" text-anchor="middle" fill="#5B6762" font-family="Arial">Illustrative image</text></svg>';
  return 'data:image/svg+xml;charset=utf-8,' + encodeURIComponent(svg);
}
function supportLink(){ return waLink(settings.supportWa, 'Assalamu alaikum. I need help with TheSuq.'); }
function cartCount(){ return cart.reduce(function(a,l){return a+l.qty;},0); }
function refreshChrome(){
  $('#cartCount').textContent = cartCount();
  $('#wishCount').textContent = wish.length;
  var a = $('#announce'); a.textContent = settings.announce; a.hidden = !settings.announce;
  var fw = $('#footWa'); var l = supportLink();
  if (l) { fw.href = l; fw.removeAttribute('aria-disabled'); fw.textContent = 'Chat with TheSuq support on WhatsApp'; }
  else { fw.href = '#/settings'; fw.textContent = 'WhatsApp support: not configured yet (set in Settings)'; }
}
function persistAll(){ save('cart',cart); save('wish',wish); save('orders',orders); save('recent',recent); save('state',myState); save('settings',settings); refreshChrome(); }

function priceHtml(p){ return '<span class="price">'+fmtNGN(p.price)+'</span>'+(p.was?'<span class="was">'+fmtNGN(p.was)+'</span>':''); }
function stockBadge(p){ var t=totalStock(p); return t===0?'<span class="badge bad">Out of stock</span>':'<span class="badge ok">In stock</span>'; }
function sellerBadge(){ return '<span class="badge warn">Not verified (demo)</span>'; }

function productCard(p){
  var s = sellerById(p.seller);
  return '<article class="card"><a class="cover" href="#/product/'+p.id+'"><img class="thumb" loading="lazy" src="'+img(p)+'" alt="'+esc(p.name)+' (illustrative image)"></a>'+
    '<div class="body"><a class="title" href="#/product/'+p.id+'" style="color:inherit;text-decoration:none">'+esc(p.name)+'</a>'+
    '<div>'+priceHtml(p)+'</div><div class="meta">'+esc(s.name)+' · '+esc(s.state)+'</div>'+
    '<div>'+stockBadge(p)+' <span class="demo-tag">Demo</span></div></div></article>';
}

/* ---------- views ---------- */
function viewHome(){
  var trending = PRODUCTS.filter(function(p){return totalStock(p)>0;}).slice(0,8);
  var deals = PRODUCTS.filter(function(p){return p.was;});
  var fresh = PRODUCTS.slice(-6).reverse();
  return '<div class="wrap">'+
  '<section class="hero"><h1>Shop and sell across Nigeria, with trade you can trust.</h1>'+
  '<p>TheSuq connects buyers with independent sellers in all 36 states and the FCT. Ask sellers questions on WhatsApp, see prices in naira, and know the rules before you buy.</p>'+
  '<div class="actions"><a class="btn btn-lime" href="#/browse">Browse products</a><a class="btn btn-ghost" style="color:#fff;border-color:#fff" href="#/policy/seller-agreement">Sell on TheSuq (preview)</a></div>'+
  '<span class="demo-tag" style="justify-self:start">Demo data: every seller and product here is fictional</span></section>'+
  '<section class="section"><h2>Categories</h2><div class="cats">'+CATS.map(function(c){return '<a class="cat-tile" href="#/browse?cat='+c.id+'"><span class="cat-ico" style="background:'+c.tint+'">'+c.ico+'</span><span>'+esc(c.name)+'</span></a>';}).join('')+'</div></section>'+
  '<section class="section"><div class="section-head"><h2>Available now</h2><a href="#/browse">See all</a></div><div class="grid">'+trending.map(productCard).join('')+'</div></section>'+
  (deals.length?'<section class="section"><h2>Reduced prices</h2><div class="grid">'+deals.map(productCard).join('')+'</div></section>':'')+
  '<section class="section"><h2>New in the preview</h2><div class="grid">'+fresh.map(productCard).join('')+'</div></section>'+
  '<section class="section"><div class="section-head"><h2>Sellers</h2><a href="#/sellers">All sellers</a></div><div class="grid">'+SELLERS.slice(0,4).map(sellerCard).join('')+'</div></section>'+
  '<section class="section"><h2>How TheSuq approaches trust</h2><div class="trust">'+
  '<div><h3>Honest listings</h3><p class="meta">Sellers must describe goods, prices and condition accurately. Fake reviews and hidden charges are prohibited.</p></div>'+
  '<div><h3>Clear rules</h3><p class="meta">Prohibited and restricted products are listed publicly. Draft policy pages are in the footer.</p></div>'+
  '<div><h3>No overclaiming</h3><p class="meta">TheSuq does not claim products are Shariah-certified. A reviewed status is shown only after a documented review.</p></div>'+
  '<div><h3>Pay safely</h3><p class="meta">Use the platform checkout. Be careful with off-platform transfers; WhatsApp chats may not be visible to TheSuq support.</p></div>'+
  '</div></section>'+
  (recent.length?'<section class="section"><h2>Recently viewed</h2><div class="grid">'+recent.map(productById).filter(Boolean).slice(0,4).map(productCard).join('')+'</div></section>':'')+
  '</div>';
}

function sellerCard(s){
  var n = PRODUCTS.filter(function(p){return p.seller===s.id;}).length;
  return '<article class="card"><div class="body"><a class="title" href="#/seller/'+s.id+'" style="color:inherit;text-decoration:none">'+esc(s.name)+'</a><div class="meta">'+esc(s.city)+', '+esc(s.state)+'</div><div>'+sellerBadge()+' <span class="demo-tag">Demo</span></div><div class="meta">'+n+' listing'+(n===1?'':'s')+'</div><a href="#/seller/'+s.id+'">Visit storefront</a></div></article>';
}

var F = {q:'', cat:'', state:'', min:'', max:'', stock:false, verified:false, sort:'rel', page:1};
function parseHash(){
  var h = location.hash.replace(/^#/, '') || '/';
  var qi = h.indexOf('?'); var path = qi<0?h:h.slice(0,qi); var qs = {};
  if (qi>=0) h.slice(qi+1).split('&').forEach(function(kv){ var a=kv.split('='); if(a[0]) qs[decodeURIComponent(a[0])]=decodeURIComponent((a[1]||'').replace(/\+/g,' ')); });
  return {path:path, qs:qs, parts:path.split('/').filter(Boolean)};
}

function viewBrowse(qs, sellerId){
  if (!sellerId) { F.q = qs.q || ''; F.cat = qs.cat || ''; }
  var list = PRODUCTS.filter(function(p){
    if (sellerId && p.seller !== sellerId) return false;
    if (F.cat && p.cat !== F.cat) return false;
    if (F.q) {
      var hay = (p.name+' '+p.desc+' '+catById(p.cat).name+' '+sellerById(p.seller).name).toLowerCase();
      if (!F.q.toLowerCase().split(/\s+/).every(function(t){return hay.indexOf(t)!==-1;})) return false;
    }
    if (F.state && sellerById(p.seller).state !== F.state) return false;
    if (F.min !== '' && p.price < Number(F.min)) return false;
    if (F.max !== '' && p.price > Number(F.max)) return false;
    if (F.stock && totalStock(p)===0) return false;
    if (F.verified) return false; // no seller is verified in the demo
    return true;
  });
  if (F.sort==='low') list.sort(function(a,b){return a.price-b.price;});
  if (F.sort==='high') list.sort(function(a,b){return b.price-a.price;});
  var per = 8, pages = Math.max(1, Math.ceil(list.length/per)); if (F.page>pages) F.page=1;
  var shown = list.slice((F.page-1)*per, F.page*per);
  var cat = F.cat ? catById(F.cat) : null;
  var title = sellerId ? '' : (cat ? cat.name : (F.q ? 'Results for "'+esc(F.q)+'"' : 'All products'));
  var opts = function(v,l){return '<option value="'+v+'"'+(F.sort===v?' selected':'')+'>'+l+'</option>';};
  var html = '<div class="'+(sellerId?'':'wrap')+'">'+(title?'<h1>'+title+'</h1>':'')+(cat?'<p class="meta">'+esc(cat.blurb)+'</p>':'')+
  '<div class="layout"><aside class="filters" aria-label="Filters"><h3>Filter</h3>'+
  (sellerId?'':'<label for="fCat">Category</label><select id="fCat" data-f="cat"><option value="">All</option>'+CATS.map(function(c){return '<option value="'+c.id+'"'+(F.cat===c.id?' selected':'')+'>'+esc(c.name)+'</option>';}).join('')+'</select>')+
  '<label for="fState">Seller location</label><select id="fState" data-f="state"><option value="">Anywhere in Nigeria</option>'+STATES.map(function(s){return '<option'+(F.state===s?' selected':'')+'>'+esc(s)+'</option>';}).join('')+'</select>'+
  '<label for="fMin">Price range (₦)</label><div style="display:flex;gap:6px"><input id="fMin" data-f="min" type="number" min="0" placeholder="Min" value="'+esc(F.min)+'"><input id="fMax" data-f="max" type="number" min="0" placeholder="Max" value="'+esc(F.max)+'" aria-label="Maximum price"></div>'+
  '<label class="chk"><input type="checkbox" data-f="stock"'+(F.stock?' checked':'')+'> In stock only</label>'+
  '<label class="chk"><input type="checkbox" data-f="verified"'+(F.verified?' checked':'')+'> Verified sellers only</label>'+
  '<button class="btn btn-ghost" style="margin-top:10px;width:100%" data-act="clearFilters">Clear filters</button></aside>'+
  '<section><div class="toolbar"><span class="meta" role="status">'+list.length+' product'+(list.length===1?'':'s')+'</span><label>Sort <select data-f="sort">'+opts('rel','Relevance')+opts('low','Price: low to high')+opts('high','Price: high to low')+'</select></label></div>'+
  (shown.length? '<div class="grid">'+shown.map(productCard).join('')+'</div>' :
    '<div class="empty"><h3>No products match</h3><p>'+(F.verified?'No seller in this preview is verified yet, because verification needs a documented review. Untick "Verified sellers only" to see demo listings.':'Try fewer filters or a different search.')+'</p><button class="btn btn-primary" data-act="clearFilters">Clear filters</button></div>')+
  (pages>1?'<div class="pager">'+Array.from({length:pages},function(_,i){return '<button data-page="'+(i+1)+'"'+(F.page===i+1?' aria-current="page"':'')+'>'+(i+1)+'</button>';}).join('')+'</div>':'')+
  '</section></div></div>';
  return html;
}

var sel = {}; // per-product selected variant/qty
function viewProduct(id){
  var p = productById(id); if (!p) return notFound();
  var s = sellerById(p.seller), c = catById(p.cat);
  recent = [id].concat(recent.filter(function(x){return x!==id;})).slice(0,8); save('recent', recent);
  var st = sel[id] || (sel[id] = {vid:null, qty:1});
  if (!st.vid) { var first = p.variants.filter(function(v){return v.stock>0;})[0]; st.vid = first ? first.id : p.variants[0].id; }
  var v = variantOf(p, st.vid);
  var available = v.stock > 0;
  if (st.qty > v.stock && available) st.qty = v.stock;
  var related = PRODUCTS.filter(function(x){return x.cat===p.cat && x.id!==p.id;}).slice(0,4);
  var loc = myState;
  var wl = waLink(settings.demoSellerWa, enquiryText(p.name, loc) + '\nListing: ' + location.href);
  var inWish = wish.indexOf(id)!==-1;
  var fee = deliveryFee(s, myState, p);
  return '<div class="wrap"><nav class="crumbs"><a href="#/">Home</a> / <a href="#/browse?cat='+c.id+'">'+esc(c.name)+'</a> / '+esc(p.name)+'</nav>'+
  '<div class="pd"><div><img class="thumb" src="'+img(p)+'" alt="'+esc(p.name)+' (illustrative image)"><p class="meta">Illustrative image. Real sellers must upload genuine photos or label images as illustrative.</p></div>'+
  '<div><h1>'+esc(p.name)+'</h1><p>'+priceHtml(p)+' '+(available?'<span class="badge ok">In stock ('+v.stock+' available)</span>':'<span class="badge bad">Out of stock</span>')+' <span class="badge">'+esc(p.cond)+'</span> <span class="demo-tag">Demo data</span></p>'+
  '<div><strong>'+esc(p.vlabel)+'</strong><div class="opts" role="group" aria-label="'+esc(p.vlabel)+'">'+p.variants.map(function(x){return '<button class="opt" data-var="'+x.id+'" aria-pressed="'+(x.id===st.vid)+'"'+(x.stock===0?' disabled':'')+'>'+esc(x.label)+(x.stock===0?' (sold out)':'')+'</button>';}).join('')+'</div></div>'+
  '<div style="display:flex;gap:10px;align-items:center;flex-wrap:wrap"><div class="qty" role="group" aria-label="Quantity"><button data-qty="-1" aria-label="Decrease quantity">−</button><span aria-live="polite">'+st.qty+'</span><button data-qty="1" aria-label="Increase quantity">+</button></div>'+
  '<button class="btn btn-primary" data-act="add" data-id="'+id+'"'+(available?'':' disabled')+'>Add to cart</button>'+
  '<button class="btn btn-lime" data-act="buy" data-id="'+id+'"'+(available?'':' disabled')+'>Buy now</button>'+
  '<button class="wish" data-act="wish" data-id="'+id+'" aria-pressed="'+inWish+'" aria-label="'+(inWish?'Remove from wishlist':'Add to wishlist')+'">'+(inWish?'♥':'♡')+'</button></div>'+
  '<div class="box"><div class="kv"><span>Sold by</span><span><a href="#/seller/'+s.id+'">'+esc(s.name)+'</a> '+sellerBadge()+'</span><span>Location</span><span>'+esc(s.city)+', '+esc(s.state)+'</span><span>Delivery to '+esc(myState)+'</span><span>'+(p.svc?'Arranged with the provider':(fee===null?'Seller does not deliver to this state'+(s.pickup?' (pickup available)':''):fmtNGN(fee)+' (seller-set fee). Delivery time: confirm with seller.'))+'</span><span>Pickup</span><span>'+(s.pickup?'Available (confirm address with seller)':'Not offered')+'</span></div></div>'+
  '<button class="btn btn-wa" data-act="wa" data-id="'+id+'" style="width:100%">Chat with Seller on WhatsApp</button>'+
  '<p class="meta">WhatsApp chats happen outside TheSuq and may not be visible to our support team. Never pay a seller by transfer outside the platform checkout.</p></div></div>'+
  '<section class="box"><h2>Description</h2><p>'+esc(p.desc)+'</p><h3>Specifications</h3><ul>'+p.specs.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ul><h3>Returns</h3><p>'+esc(p.returns)+' <a href="#/policy/returns">Returns and Refunds Policy (draft)</a></p></section>'+
  '<section class="box"><h2>Reviews</h2><p class="meta">Reviews can only be written by buyers with a completed order. There are no reviews in this preview.</p><button class="btn btn-ghost" data-act="report" data-id="'+id+'">Report this listing</button></section>'+
  (related.length?'<section class="section"><h2>Related products</h2><div class="grid">'+related.map(productCard).join('')+'</div></section>':'')+'</div>';
}

function viewSeller(id){
  var s = sellerById(id); if (!s) return notFound();
  return '<div class="wrap"><nav class="crumbs"><a href="#/">Home</a> / <a href="#/sellers">Sellers</a> / '+esc(s.name)+'</nav>'+
  '<section class="hero" style="padding:24px"><h1>'+esc(s.name)+'</h1><p>'+esc(s.desc)+'</p><div>'+sellerBadge()+' <span class="demo-tag">Fictional seller</span></div></section>'+
  '<div class="box"><div class="kv"><span>Location</span><span>'+esc(s.city)+', '+esc(s.state)+'</span><span>Delivery</span><span>'+(s.nationwide?'Nationwide (seller-set fees)':'Selected states: '+esc((s.deliverStates||[]).join(', ')))+'</span><span>Pickup</span><span>'+(s.pickup?'Available':'Not offered')+'</span><span>Response time</span><span>Not reported in preview</span><span>Ratings</span><span>None yet (reviews need completed orders)</span></div>'+
  '<button class="btn btn-wa" style="margin-top:10px" data-act="waSeller" data-id="'+s.id+'">Chat with Seller on WhatsApp</button></div>'+
  '<h2>Listings</h2>'+viewBrowse({}, id)+'</div>';
}
function viewSellers(){ return '<div class="wrap"><h1>Sellers</h1><p class="meta">All sellers below are fictional. None is verified.</p><div class="grid">'+SELLERS.map(sellerCard).join('')+'</div></div>'; }

function viewWishlist(){
  var items = wish.map(productById).filter(Boolean);
  return '<div class="wrap"><h1>Wishlist</h1>'+(items.length?'<div class="grid">'+items.map(productCard).join('')+'</div>':'<div class="empty"><p>Your wishlist is empty.</p><a class="btn btn-primary" href="#/browse">Browse products</a></div>')+'<p class="meta">Saved on this device only (preview). Accounts are part of the next build phase.</p></div>';
}

function viewCart(){
  if (!cart.length) return '<div class="wrap"><h1>Cart</h1><div class="empty"><p>Your cart is empty.</p><a class="btn btn-primary" href="#/browse">Browse products</a></div></div>';
  var c = computeCart(cart, myState, 'delivery', load('coupon',''));
  var groups = Object.keys(c.groups).map(function(id){
    var g = c.groups[id];
    return '<div class="box"><h3>'+esc(g.seller.name)+' <span class="meta">('+esc(g.seller.state)+')</span></h3>'+
    g.lines.map(function(l){
      return '<div class="cart-row"><img src="'+img(l.p)+'" alt=""><div><a href="#/product/'+l.p.id+'">'+esc(l.p.name)+'</a><div class="meta">'+esc(l.p.vlabel)+': '+esc(l.v.label)+'</div>'+
      '<div class="qty" role="group" aria-label="Quantity"><button data-cq="-1" data-k="'+l.p.id+'|'+l.v.id+'" aria-label="Decrease">−</button><span>'+l.qty+'</span><button data-cq="1" data-k="'+l.p.id+'|'+l.v.id+'" aria-label="Increase">+</button></div>'+
      (l.qty>l.v.stock?'<div class="badge bad">Only '+l.v.stock+' in stock</div>':'')+
      '<div><button class="opt" style="padding:3px 8px;font-size:.8rem" data-act="rm" data-k="'+l.p.id+'|'+l.v.id+'">Remove</button> <button class="opt" style="padding:3px 8px;font-size:.8rem" data-act="later" data-k="'+l.p.id+'|'+l.v.id+'">Save for later</button></div></div><strong>'+fmtNGN(l.line)+'</strong></div>';
    }).join('')+
    '<div class="sum-row"><span>Delivery to '+esc(myState)+'</span><span>'+(g.blocked?'<span class="badge bad">Not available</span>':fmtNGN(g.fee))+'</span></div></div>';
  }).join('');
  var saved = load('later', []);
  return '<div class="wrap"><h1>Cart</h1><div class="two"><div>'+groups+
  (saved.length?'<div class="box"><h3>Saved for later</h3>'+saved.map(function(k){var a=k.split('|'),p=productById(a[0]);return p?'<div class="sum-row"><span>'+esc(p.name)+'</span><button class="opt" data-act="unlater" data-k="'+k+'">Move to cart</button></div>':'';}).join('')+'</div>':'')+
  '</div><aside class="box" style="align-self:start"><h3>Summary</h3>'+
  '<div class="sum-row"><span>Subtotal</span><span>'+fmtNGN(c.subtotal)+'</span></div><div class="sum-row"><span>Delivery (estimate)</span><span>'+fmtNGN(c.delivery)+'</span></div>'+
  (c.discount?'<div class="sum-row"><span>Demo coupon</span><span>−'+fmtNGN(c.discount)+'</span></div>':'')+
  '<div class="sum-row total"><span>Total</span><span>'+fmtNGN(c.total)+'</span></div>'+
  (c.problems.length?'<div class="notice" role="alert"><strong>Fix before checkout:</strong><ul>'+c.problems.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ul>Change your state in the header, or choose pickup at checkout where offered.</div>':'')+
  '<a class="btn btn-primary" style="display:block;margin-top:10px" href="#/checkout">Checkout</a>'+
  '<p class="meta">Marketplace fees are charged to sellers and are shown in the Seller Agreement draft. Delivery fees are set by sellers.</p></aside></div></div>';
}

function viewCheckout(){
  if (!cart.length) { location.hash = '#/cart'; return ''; }
  var d = load('draftCheckout', {mode:'delivery', state:myState, coupon:load('coupon','')});
  var c = computeCart(cart, d.state, d.mode, d.coupon);
  var f = function(id,label,type,ph,val,extra){ return '<div class="field"><label for="'+id+'">'+label+'</label><input id="'+id+'" name="'+id+'" type="'+(type||'text')+'" placeholder="'+(ph||'')+'" value="'+esc(val||'')+'" '+(extra||'')+'><div class="err" id="e-'+id+'"></div></div>'; };
  return '<div class="wrap"><h1>Checkout</h1><div class="notice sandbox" role="note"><strong>SANDBOX / DEMO.</strong> No payment provider is connected in this preview. Placing an order saves a demo order on this device with status "Pending payment". Nothing is charged and nothing is sent to sellers.</div>'+
  '<form id="coForm" novalidate class="two" style="margin-top:14px"><div><div class="box"><h2>Contact and delivery</h2><div class="form-grid">'+
  f('name','Recipient full name','text','',d.name,'autocomplete="name"')+f('phone','Nigerian phone number','tel','e.g. 08031234567',d.phone,'autocomplete="tel" inputmode="tel"')+
  f('email','Email (optional)','email','',d.email,'autocomplete="email"')+
  '<div class="field"><label for="state">State</label><select id="state" name="state">'+STATES.map(function(s){return '<option'+(s===d.state?' selected':'')+'>'+esc(s)+'</option>';}).join('')+'</select></div>'+
  f('lga','LGA / city','text','',d.lga)+f('landmark','Landmark (optional)','text','',d.landmark)+'</div>'+
  f('address','Street address','text','',d.address,'autocomplete="street-address"')+
  '<fieldset style="border:0;padding:0"><legend><strong>Delivery method</strong></legend><label class="chk"><input type="radio" name="mode" value="delivery"'+(d.mode==='delivery'?' checked':'')+'> Delivery</label><label class="chk"><input type="radio" name="mode" value="pickup"'+(d.mode==='pickup'?' checked':'')+'> Pickup from seller (where offered)</label></fieldset></div>'+
  '<div class="box"><h2>Payment</h2><label class="chk"><input type="radio" checked disabled> Card / bank transfer via Paystack or Flutterwave (sandbox, not connected)</label><p class="meta">Orders are marked paid only after server-side verification. That requires the backend built in a later phase.</p></div>'+
  '<div class="box"><label class="chk"><input type="checkbox" id="terms"> I have read the <a href="#/policy/terms" target="_blank">Terms</a> and <a href="#/policy/returns" target="_blank">Returns Policy</a> (drafts).</label><div class="err" id="e-terms" style="color:var(--err)"></div></div></div>'+
  '<aside class="box" style="align-self:start"><h3>Order summary</h3>'+
  Object.keys(c.groups).map(function(id){var g=c.groups[id];return '<div style="margin-bottom:8px"><strong>'+esc(g.seller.name)+'</strong>'+g.lines.map(function(l){return '<div class="sum-row"><span>'+l.qty+' × '+esc(l.p.name)+' ('+esc(l.v.label)+')</span><span>'+fmtNGN(l.line)+'</span></div>';}).join('')+'<div class="sum-row meta"><span>Delivery</span><span>'+(g.blocked?'Not available':fmtNGN(g.fee))+'</span></div></div>';}).join('')+
  '<div class="field"><label for="coupon">Coupon (try DEMO10)</label><div style="display:flex;gap:6px"><input id="coupon" value="'+esc(d.coupon)+'"><button type="button" class="btn btn-ghost" data-act="applyCoupon">Apply</button></div></div>'+
  '<div class="sum-row"><span>Subtotal</span><span>'+fmtNGN(c.subtotal)+'</span></div><div class="sum-row"><span>Delivery</span><span>'+fmtNGN(c.delivery)+'</span></div>'+(c.discount?'<div class="sum-row"><span>Discount</span><span>−'+fmtNGN(c.discount)+'</span></div>':'')+
  '<div class="sum-row total"><span>Total</span><span>'+fmtNGN(c.total)+'</span></div>'+
  (c.problems.length?'<div class="notice" role="alert"><ul>'+c.problems.map(function(x){return '<li>'+esc(x)+'</li>';}).join('')+'</ul></div>':'')+
  '<button class="btn btn-primary" style="width:100%;margin-top:10px" type="submit"'+(c.problems.length?' disabled':'')+'>Place demo order</button></aside></form></div>';
}

function viewOrders(){
  return '<div class="wrap"><h1>My demo orders</h1>'+(orders.length?'<table><thead><tr><th>Reference</th><th>Date</th><th>Total</th><th>Status</th></tr></thead><tbody>'+orders.map(function(o){return '<tr><td><a href="#/order/'+o.id+'">'+o.id+'</a></td><td>'+new Date(o.at).toLocaleString('en-NG')+'</td><td>'+fmtNGN(o.total)+'</td><td><span class="badge warn">'+esc(o.status)+'</span></td></tr>';}).join('')+'</tbody></table>':'<div class="empty"><p>No demo orders yet.</p></div>')+'</div>';
}
function viewOrder(id){
  var o = orders.filter(function(x){return x.id===id;})[0]; if (!o) return notFound();
  return '<div class="wrap"><h1>Order '+o.id+'</h1><div class="notice sandbox">Demo order. No payment was taken and no seller was notified.</div>'+
  '<div class="box"><div class="kv"><span>Status</span><span><span class="badge warn">'+esc(o.status)+'</span></span><span>Payment</span><span>'+esc(o.payment)+'</span><span>Recipient</span><span>'+esc(o.name)+', '+esc(o.phone)+'</span><span>'+(o.mode==='pickup'?'Pickup':'Deliver to')+'</span><span>'+(o.mode==='pickup'?'Collect from seller':esc(o.address)+', '+esc(o.lga)+', '+esc(o.state)+(o.landmark?' (near '+esc(o.landmark)+')':''))+'</span></div></div>'+
  o.subs.map(function(s){return '<div class="box"><h3>Seller order: '+esc(s.seller)+' <span class="badge">'+esc(s.status)+'</span></h3>'+s.items.map(function(i){return '<div class="sum-row"><span>'+i.qty+' × '+esc(i.name)+' ('+esc(i.variant)+')</span><span>'+fmtNGN(i.line)+'</span></div>';}).join('')+'<div class="sum-row meta"><span>Delivery</span><span>'+fmtNGN(s.fee)+'</span></div></div>';}).join('')+
  '<div class="box"><div class="sum-row"><span>Subtotal</span><span>'+fmtNGN(o.subtotal)+'</span></div><div class="sum-row"><span>Delivery</span><span>'+fmtNGN(o.delivery)+'</span></div>'+(o.discount?'<div class="sum-row"><span>Discount</span><span>−'+fmtNGN(o.discount)+'</span></div>':'')+'<div class="sum-row total"><span>Total</span><span>'+fmtNGN(o.total)+'</span></div></div>'+
  '<div class="box"><h3>Timeline</h3><ul><li>'+new Date(o.at).toLocaleString('en-NG')+': demo order created, awaiting payment (payment provider not configured).</li></ul></div></div>';
}

var POLICIES = {
  shariah:{t:'Shariah Trade Principles', b:['TheSuq aims to host honest, transparent and lawful trade. This page is a draft template.','Sellers must describe goods accurately, state the real price and any charges, deliver what was ordered, and honour stated return terms.','Fraud, fake reviews, hidden charges, deceptive scarcity, impersonation and rating manipulation are prohibited.','TheSuq will not offer interest-bearing credit, interest-based late fees, gambling or speculative products.','TheSuq does not claim that every product or seller is Shariah-certified. A reviewed status may be shown only after a documented review recording the reviewer, scope, date and evidence.','Suspected violations can be reported from any listing. Reports go to a moderation queue with an escalation procedure.']},
  prohibited:{t:'Prohibited and Restricted Products', b:['This is a draft list to be finalised by a qualified Shariah adviser and Nigerian legal counsel.','Prohibited: intoxicants, pork products, pornography, gambling products and services, interest-based lending products, stolen goods, counterfeit goods, and anything illegal in Nigeria.','Restricted: items that need licences, age limits or special handling will be listed once reviewed.','Listings that breach this policy are removed and repeat offenders are suspended.']},
  terms:{t:'Terms of Use', b:['Draft template. Replace with terms reviewed by Nigerian counsel.','Topics to cover: account rules, marketplace role of TheSuq, seller responsibilities, orders and payment, delivery, returns, prohibited items, dispute process, liability, governing law.']},
  privacy:{t:'Privacy Policy', b:['Draft template. Must be reviewed against the Nigeria Data Protection Act and applicable guidance before launch.','Topics to cover: data collected, purposes, lawful basis, sharing with sellers and payment providers, retention, security, data subject rights and requests, contact details, cookies and analytics.','This preview stores cart, wishlist and demo orders only in your browser on this device.']},
  returns:{t:'Returns and Refunds Policy', b:['Draft template. Final windows and conditions are set by TheSuq and sellers after legal review.','Each listing states its own return terms. Refunds are processed only when the payment provider confirms them.']},
  delivery:{t:'Delivery Policy', b:['Draft template. Delivery fees and areas are set by sellers. Nationwide delivery is shown only where a seller supports it.','Delivery estimates and tracking appear only where configured or integrated with a courier.']},
  'buyer-protection':{t:'Buyer Protection and Dispute Policy', b:['Draft template. TheSuq does not currently claim guaranteed buyer protection or escrow.','Describe the real dispute process, evidence required, timelines and outcomes once the legal and payment arrangements are confirmed.']},
  'seller-agreement':{t:'Seller Agreement', b:['Draft template. Sellers must see and accept all fees before listing.','Topics to cover: eligibility and verification, honest listings, prohibited products, fees and commissions (to be decided), settlement arrangements, returns, suspension, data handling.','Seller onboarding is part of the next build phase and is not available in this preview.']}
};
function viewPolicy(k){
  var p = POLICIES[k]; if (!p) return notFound();
  return '<div class="wrap prose"><h1>'+p.t+'</h1><div class="notice"><strong>Draft.</strong> Professional Shariah and legal review is required before launch.</div>'+p.b.map(function(x){return '<p>'+esc(x)+'</p>';}).join('')+'</div>';
}

function viewHelp(){
  var sl = supportLink();
  return '<div class="wrap prose"><h1>Help centre</h1>'+
  '<div class="box"><h2>Contact support</h2>'+(sl?'<a class="btn btn-wa" href="'+sl+'" target="_blank" rel="noopener">Chat with TheSuq support on WhatsApp</a>':'<p>The support WhatsApp number is not configured. Set it in <a href="#/settings">Settings</a>. Until then, an internal support form will be available once the backend phase is built.</p>')+'</div>'+
  '<div class="box"><h2>Stay safe</h2><ul><li>Pay through the platform checkout and confirm the payment status on your order page.</li><li>Be cautious with any request to pay by transfer outside TheSuq.</li><li>WhatsApp chats are outside TheSuq and may not be visible to our support team.</li><li>TheSuq will never ask for your card PIN or OTP.</li></ul></div>'+
  '<h2>FAQs</h2><details><summary>Is every product Shariah-certified?</summary><p>No. TheSuq has a prohibited products policy, and a reviewed status is shown only after a documented review.</p></details>'+
  '<details><summary>Can I pay with Paystack or Flutterwave?</summary><p>Not in this preview. Payment is built as a sandbox in a later phase and goes live only after provider approval and testing.</p></details>'+
  '<details><summary>Do you deliver to my state?</summary><p>That depends on the seller. Each listing shows the delivery fee to the state selected in the header, or tells you if the seller does not deliver there.</p></details>'+
  '<details><summary>How do I report a listing?</summary><p>Open the product page and choose "Report this listing".</p></details>'+
  '<p><a href="#/policy/terms">Terms</a> · <a href="#/policy/privacy">Privacy</a> · <a href="#/policy/buyer-protection">Disputes</a></p></div>';
}

function viewSettings(){
  return '<div class="wrap prose"><h1>Settings (demo admin)</h1><div class="notice">These settings are saved in your browser only. In the full build they live in the database behind admin login. Never enter secrets here.</div>'+
  '<form id="setForm" class="box"><div class="field"><label for="sw">TheSuq support WhatsApp number</label><input id="sw" value="'+esc(settings.supportWa)+'" placeholder="e.g. 2348031234567"><div class="meta">International format. Leave empty until you have an official number.</div></div>'+
  '<div class="field"><label for="dw">Test number for seller WhatsApp buttons</label><input id="dw" value="'+esc(settings.demoSellerWa)+'" placeholder="Use your own number to test"><div class="meta">Demo sellers have no real numbers. Use only a number you own, to see how the link opens.</div></div>'+
  '<div class="field"><label for="an">Announcement bar text</label><input id="an" value="'+esc(settings.announce)+'"></div>'+
  '<button class="btn btn-primary" type="submit">Save</button> <button class="btn btn-ghost" type="button" data-act="resetDemo">Clear demo data (cart, orders, wishlist)</button></form></div>';
}

function viewStatus(){
  var rows = [
    ['Homepage, navigation, categories, search, filters, sorting, pagination','Built (preview)'],
    ['Product pages with variants, stock limits, wishlist, report listing','Built (preview)'],
    ['Seller storefronts and seller list','Built (preview)'],
    ['Cart (grouped by seller), delivery fees by state, save for later, coupon DEMO10','Built (preview)'],
    ['Checkout form with Nigerian phone and address validation, demo order','Built (preview, no payment)'],
    ['WhatsApp links (wa.me, encoded message, configurable numbers)','Built; needs real numbers in Settings'],
    ['Policy and help pages','Draft text; legal and Shariah review required'],
    ['Accounts, roles, database, row-level security','Not built (Phase 2)'],
    ['Seller onboarding, listing management, seller dashboard','Not built (Phase 2)'],
    ['Paystack / Flutterwave, webhooks, refunds','Not built (Phase 3)'],
    ['Admin dashboard, moderation, audit log, policy versioning','Not built (Phase 4)'],
    ['Reviews from completed purchases','Not built (needs orders)'],
    ['Security review, accessibility audit, SEO sitemap','Not done (Phase 5)']
  ];
  return '<div class="wrap prose"><h1>Build status</h1><p>Honest status of this preview against the master prompt.</p><table><thead><tr><th>Item</th><th>Status</th></tr></thead><tbody>'+rows.map(function(r){return '<tr><td>'+r[0]+'</td><td>'+r[1]+'</td></tr>';}).join('')+'</tbody></table></div>';
}
function notFound(){ return '<div class="wrap"><div class="empty"><h1>Page not found</h1><a class="btn btn-primary" href="#/">Go home</a></div></div>'; }

/* ---------- router ---------- */
function renderNav(active){
  $('#catNav').innerHTML = '<a href="#/browse"'+(!active?' aria-current="page"':'')+'>All</a>'+CATS.map(function(c){return '<a href="#/browse?cat='+c.id+'"'+(active===c.id?' aria-current="page"':'')+'>'+c.ico+' '+esc(c.name)+'</a>';}).join('');
}
function route(){
  var h = parseHash(), p = h.parts, html, active = '';
  switch (p[0]) {
    case undefined: html = viewHome(); document.title='TheSuq Marketplace | Shop and sell across Nigeria'; break;
    case 'browse': active = h.qs.cat||''; html = viewBrowse(h.qs); document.title='Browse | TheSuq'; break;
    case 'product': html = viewProduct(p[1]); var pr=productById(p[1]); document.title = (pr?pr.name:'Product')+' | TheSuq'; break;
    case 'seller': html = viewSeller(p[1]); document.title='Seller | TheSuq'; break;
    case 'sellers': html = viewSellers(); document.title='Sellers | TheSuq'; break;
    case 'wishlist': html = viewWishlist(); document.title='Wishlist | TheSuq'; break;
    case 'cart': html = viewCart(); document.title='Cart | TheSuq'; break;
    case 'checkout': html = viewCheckout(); document.title='Checkout | TheSuq'; break;
    case 'orders': html = viewOrders(); document.title='Orders | TheSuq'; break;
    case 'order': html = viewOrder(p[1]); document.title='Order | TheSuq'; break;
    case 'policy': html = viewPolicy(p[1]); document.title=(POLICIES[p[1]]?POLICIES[p[1]].t:'Policy')+' | TheSuq'; break;
    case 'help': html = viewHelp(); document.title='Help | TheSuq'; break;
    case 'settings': html = viewSettings(); document.title='Settings | TheSuq'; break;
    case 'status': html = viewStatus(); document.title='Build status | TheSuq'; break;
    default: html = notFound();
  }
  renderNav(active);
  mainEl.innerHTML = html;
  if (p[0] !== 'product' || true) window.scrollTo(0,0);
  refreshChrome();
  var q = $('#q'); if (p[0]==='browse') q.value = h.qs.q || '';
}
function rerender(){ var y = window.scrollY; route(); window.scrollTo(0,y); }

/* ---------- actions ---------- */
function addToCart(pid, qty){
  var p = productById(pid), st = sel[pid]; var v = variantOf(p, st.vid);
  var line = cart.filter(function(l){return l.pid===pid && l.vid===st.vid;})[0];
  var have = line ? line.qty : 0;
  if (have + qty > v.stock) { toast('Only ' + v.stock + ' in stock for this option.'); return false; }
  if (line) line.qty += qty; else cart.push({pid:pid, vid:st.vid, qty:qty});
  persistAll(); return true;
}
function keyLine(k){ var a=k.split('|'); return cart.filter(function(l){return l.pid===a[0]&&l.vid===a[1];})[0]; }

function openDialog(html){
  var d = document.createElement('dialog'); d.innerHTML = html + '<p style="text-align:right"><button class="btn btn-ghost" data-close>Close</button></p>';
  document.body.appendChild(d);
  d.addEventListener('click', function(e){ if (e.target.hasAttribute('data-close') || e.target===d) { d.close(); d.remove(); } });
  d.addEventListener('close', function(){ d.remove(); });
  d.showModal(); return d;
}
function openWa(pid, sellerId){
  var p = pid ? productById(pid) : null, s = sellerById(sellerId || p.seller);
  var text = p ? enquiryText(p.name, myState) + '\nListing: ' + location.href : 'Assalamu alaikum. I would like to ask about your shop on TheSuq (' + s.name + '). Thank you.';
  var link = waLink(settings.demoSellerWa, text);
  if (link) { window.open(link, '_blank', 'noopener'); return; }
  openDialog('<h2>WhatsApp not configured</h2><p>Demo sellers have no real phone numbers, and TheSuq never invents contact details. To test how the link opens, add a number you own under <a href="#/settings">Settings</a>.</p><p><strong>Message that would be sent:</strong></p><p style="white-space:pre-wrap;background:var(--sand);padding:10px;border-radius:8px">'+esc(text)+'</p><p class="meta">Alternative: use the Help centre to contact TheSuq support.</p>');
}
function openReport(pid){
  var p = productById(pid);
  var d = openDialog('<h2>Report this listing</h2><p class="meta">'+esc(p.name)+'</p><form id="repForm"><div class="field"><label for="rr">Reason</label><select id="rr"><option>Prohibited or restricted product</option><option>Counterfeit or misleading</option><option>Wrong price or hidden charges</option><option>Fraud or scam suspicion</option><option>Other</option></select></div><div class="field"><label for="rd">Details</label><textarea id="rd" rows="3"></textarea></div><button class="btn btn-primary" type="submit">Submit report</button></form><p class="meta">Preview: reports are saved on this device only. In the full build they go to the moderation queue.</p>');
  d.querySelector('#repForm').addEventListener('submit', function(e){ e.preventDefault(); var r = load('reports',[]); r.push({pid:pid, reason:d.querySelector('#rr').value, details:d.querySelector('#rd').value, at:Date.now()}); save('reports', r); d.close(); d.remove(); toast('Report saved (demo).'); });
}

function placeOrder(form){
  var d = readCheckout();
  var errs = {};
  if (!d.name.trim()) errs.name = 'Enter the recipient name.';
  if (!isNgPhone(d.phone)) errs.phone = 'Enter a valid Nigerian number, e.g. 08031234567 or +2348031234567.';
  if (d.email && !/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(d.email)) errs.email = 'Enter a valid email or leave blank.';
  if (d.mode === 'delivery') { if (!d.lga.trim()) errs.lga = 'Enter your LGA or city.'; if (!d.address.trim()) errs.address = 'Enter your street address.'; }
  if (!form.querySelector('#terms').checked) errs.terms = 'Please accept the terms to continue.';
  ['name','phone','email','lga','address','terms'].forEach(function(k){ var e = form.querySelector('#e-'+k); if (e) e.textContent = errs[k] || ''; var i = form.querySelector('#'+k); if (i && i.type!=='checkbox') i.setAttribute('aria-invalid', errs[k]?'true':'false'); });
  var keys = Object.keys(errs);
  if (keys.length) { var f = form.querySelector('#'+keys[0]); if (f) f.focus(); return; }
  var c = computeCart(cart, d.state, d.mode, d.coupon);
  if (c.problems.length) { toast(c.problems[0]); return; }
  var id = 'TS-' + Date.now().toString(36).toUpperCase();
  var o = {id:id, at:Date.now(), status:'Pending payment', payment:'Not paid. Payment provider not configured (sandbox preview).', name:d.name, phone:d.phone, email:d.email, state:d.state, lga:d.lga, address:d.address, landmark:d.landmark, mode:d.mode,
    subtotal:c.subtotal, delivery:c.delivery, discount:c.discount, total:c.total,
    subs:Object.keys(c.groups).map(function(k){var g=c.groups[k];return {seller:g.seller.name, status:'Awaiting payment', fee:g.fee, items:g.lines.map(function(l){return {name:l.p.name, variant:l.v.label, qty:l.qty, line:l.line};})};})};
  orders.unshift(o); cart = []; save('draftCheckout', null); persistAll();
  location.hash = '#/order/' + id;
}
function readCheckout(){
  var f = $('#coForm'), g = function(n){ var e = f.querySelector('[name="'+n+'"]'); return e ? e.value : ''; };
  var mode = (f.querySelector('input[name=mode]:checked')||{}).value || 'delivery';
  return {name:g('name'), phone:g('phone'), email:g('email'), state:g('state'), lga:g('lga'), landmark:g('landmark'), address:g('address'), mode:mode, coupon:(f.querySelector('#coupon')||{}).value||''};
}

/* ---------- events ---------- */
document.addEventListener('click', function(e){
  var t = e.target.closest('button, a'); if (!t) return;
  var act = t.getAttribute('data-act'), id = t.getAttribute('data-id');
  if (t.hasAttribute('data-var')) { var pid = parseHash().parts[1]; sel[pid].vid = t.getAttribute('data-var'); sel[pid].qty = 1; return rerender(); }
  if (t.hasAttribute('data-qty')) { var pid2 = parseHash().parts[1], p2 = productById(pid2), v2 = variantOf(p2, sel[pid2].vid); var q = sel[pid2].qty + Number(t.getAttribute('data-qty')); if (q<1) q=1; if (q>v2.stock) { q=v2.stock; toast('Only '+v2.stock+' in stock.'); } sel[pid2].qty = q; return rerender(); }
  if (t.hasAttribute('data-page')) { F.page = Number(t.getAttribute('data-page')); return rerender(); }
  if (t.hasAttribute('data-cq')) { var ln = keyLine(t.getAttribute('data-k')); var nq = ln.qty + Number(t.getAttribute('data-cq')); var vv = variantOf(productById(ln.pid), ln.vid); if (nq<1) nq=1; if (nq>vv.stock) { nq=vv.stock; toast('Only '+vv.stock+' in stock.'); } ln.qty = nq; persistAll(); return rerender(); }
  switch (act) {
    case 'add': if (addToCart(id, sel[id].qty)) toast('Added to cart'); break;
    case 'buy': if (addToCart(id, sel[id].qty)) location.hash = '#/checkout'; break;
    case 'wish': var i = wish.indexOf(id); if (i<0) wish.push(id); else wish.splice(i,1); persistAll(); rerender(); break;
    case 'wa': openWa(id); break;
    case 'waSeller': openWa(null, id); break;
    case 'report': openReport(id); break;
    case 'clearFilters': F = {q:'', cat:'', state:'', min:'', max:'', stock:false, verified:false, sort:'rel', page:1}; if (parseHash().parts[0]==='browse') location.hash='#/browse'; rerender(); break;
    case 'rm': var k = t.getAttribute('data-k').split('|'); cart = cart.filter(function(l){return !(l.pid===k[0]&&l.vid===k[1]);}); persistAll(); rerender(); break;
    case 'later': var kk = t.getAttribute('data-k'); var sv = load('later',[]); if (sv.indexOf(kk)<0) sv.push(kk); save('later', sv); var a = kk.split('|'); cart = cart.filter(function(l){return !(l.pid===a[0]&&l.vid===a[1]);}); persistAll(); rerender(); break;
    case 'unlater': var k3 = t.getAttribute('data-k'), a3 = k3.split('|'); sel[a3[0]] = {vid:a3[1], qty:1}; if (addToCart(a3[0],1)) { save('later', load('later',[]).filter(function(x){return x!==k3;})); } rerender(); break;
    case 'applyCoupon': var cv = $('#coupon').value.trim(); var cur = readCheckout(); cur.coupon = cv; save('draftCheckout', cur); save('coupon', cv); if (cv && cv.toUpperCase()!=='DEMO10') toast('Coupon not recognised.'); rerender(); break;
    case 'resetDemo': cart=[]; wish=[]; orders=[]; recent=[]; save('later',[]); save('reports',[]); persistAll(); toast('Demo data cleared'); rerender(); break;
  }
});
document.addEventListener('change', function(e){
  var t = e.target;
  if (t.hasAttribute('data-f')) { var k = t.getAttribute('data-f'); F[k] = t.type==='checkbox' ? t.checked : t.value; F.page = 1; return rerender(); }
  if (t.closest('#coForm') && (t.name==='mode' || t.name==='state')) { var cur = readCheckout(); save('draftCheckout', cur); rerender(); }
});
document.addEventListener('submit', function(e){
  if (e.target.id === 'searchForm') { e.preventDefault(); location.hash = '#/browse?q=' + encodeURIComponent($('#q').value.trim()); }
  if (e.target.id === 'coForm') { e.preventDefault(); placeOrder(e.target); }
  if (e.target.id === 'setForm') {
    e.preventDefault();
    var sw = $('#sw').value.trim(), dw = $('#dw').value.trim();
    if ((sw && !normalizeWaNumber(sw)) || (dw && !normalizeWaNumber(dw))) { toast('Enter numbers in international format, e.g. 2348031234567.'); return; }
    settings.supportWa = sw; settings.demoSellerWa = dw; settings.announce = $('#an').value.trim(); persistAll(); toast('Settings saved');
  }
});
document.addEventListener('input', function(e){ if (e.target.closest && e.target.closest('#coForm')) { /* keep typed values across re-renders */ var cur = readCheckout(); save('draftCheckout', cur); } });

var stSel = $('#stateSel');
stSel.innerHTML = STATES.map(function(s){return '<option'+(s===myState?' selected':'')+'>'+esc(s)+'</option>';}).join('');
stSel.addEventListener('change', function(){ myState = stSel.value; persistAll(); rerender(); });
window.addEventListener('hashchange', route);
route();
})();
